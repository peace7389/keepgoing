#include <stdio.h>
#include <stdlib.h>


struct Node
{
    int data;
    struct Node * next;
};


int main(){
    
    int var = 10;
    int * ptr1 = &var;
    
      
    int ** ptr2 = &ptr1;
    
    
    printf("%p \n" , ptr1);
    printf("%p \n" , ptr2);
    printf("%d \n" , sizeof(ptr1));
    printf("%d \n" , sizeof(&ptr1));
    printf("%d \n" , sizeof(*ptr1));
}
