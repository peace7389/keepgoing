# 3D Hand Pose Estimation

3D hand pose estimation is defined as the task of detecting the poses (or keypoints) of the hand from an input image.

## Data preparation

Please follow [DATA Preparation](/docs/en/tasks/3d_hand_keypoint.md) to prepare data.
