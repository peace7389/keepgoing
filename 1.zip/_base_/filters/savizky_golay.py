filter_cfg = dict(
    type='SavizkyGolayFilter',
    window_size=11,
    polyorder=2,
)
